const RoundHistory = (() => {
  const maps = /\b(Ancient|Mirage|Anubis|Dust\s*(?:II|2)|Inferno|Nuke|Overpass|Train|Vertigo|Cache|Tuscan|Thera|Mills)\b/i;
  const dates = /\b\d{1,2}\s+(?:янв|фев|мар|апр|ма[йя]|июн|июл|авг|сен|окт|ноя|дек|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-zа-яё]*\.?(?:[ ,]+\d{4})?/iu;
  function parse(text, leaves, date, ratingText) {
    const usDate=text.match(/\b(Jan[a-z]*|Feb[a-z]*|Mar[a-z]*|Apr[a-z]*|May|Jun[a-z]*|Jul[a-z]*|Aug[a-z]*|Sep[a-z]*|Oct[a-z]*|Nov[a-z]*|Dec[a-z]*)\.?\s+(\d{1,2})\b(?:,?\s+(\d{4})\b)?/i);
    const day = date || text.match(dates)?.[0] || (usDate && [usDate[2],usDate[1],usDate[3]].filter(Boolean).join(' '));
    if (!day) return null;
    const rawMap = text.match(maps)?.[0] || '';
    const map = /^dust/i.test(rawMap) ? 'Dust 2' : rawMap;
    // The date cell may supply the clock, or a time element may carry only a timestamp.
    const afterDate = text.replace(usDate?.[0]||dates,'').trim();
    const afterClock = afterDate.replace(/^(?:[а-яёa-z]{2,4}[.,]?\s+)?(?:[01]?\d|2[0-3]):[0-5]\d(?=\s)/iu,'').trim();
    const score = afterClock.match(/(?:^|\s)(\d{1,2})\s*:\s*(\d{1,2})(?=\s|$)/);
    const prefix = ratingText || '';
    const signed = text.match(/(?:^|\s)([↑↓+−-])\s*(\d{1,3})(?=\s|$)/);
    const pair = prefix.match(/\b(\d{3,4})\s+(\d{1,3})\s*$/);
    const bits= text.trim().split(/\s+/);
    const badge=bits.find(v=>/^(п|в|w|l)$/i.test(v));
    const won = score && +score[1]!==+score[2] ? +score[1]>+score[2] : badge&&/^[вw]$/i.test(badge)?true:badge&&/^l$/i.test(badge)?false:null;
    const delta = signed ? (/[-↓−]/.test(signed[1])?-1:1)*Number(signed[2]) : pair && won!==null ? (won?1:-1)*Number(pair[2]) : null;
    return {day,map,won,delta};
  }
  function read(row,locale="ru"){
    const nodes=document.createTreeWalker(row,NodeFilter.SHOW_TEXT);
    const leaves=[];
    while(nodes.nextNode()){
      const s=nodes.currentNode.textContent.trim();
      if(s)leaves.push(s);
    }
    const text=leaves.join(' ');
    const time=row.querySelector('time[datetime]');
    const ts=time && Date.parse(time.dateTime);
    const date=Number.isFinite(ts)?new Intl.DateTimeFormat(locale,{day:'numeric',month:'long',year:'numeric'}).format(ts):null;
    let rating='';
    for(const el of row.querySelectorAll('span,div,td,[role="cell"]')){
      const tokens=el.textContent.trim();
      if(!/^\d{3,4}$/.test(tokens)||el.children.length)continue;
      let parent=el.parentElement;
      for(let i=0;i<3 && parent && parent!==row;i++,parent=parent.parentElement){
        const amounts=Array.from(parent.querySelectorAll('*')).filter(n=>!n.children.length).map(n=>n.textContent.trim()).filter(Boolean);
        const at=amounts.indexOf(tokens);
        if(at>=0 && /^\d{1,3}$/.test(amounts[at+1]||'')){rating=tokens+' '+amounts[at+1];break;}
      }
      if(rating)break;
    }
    const parsed=parse(text,leaves,date,rating);
    if(parsed && parsed.delta===null && parsed.won!==null){
      // FACEIT sometimes draws the direction as an SVG between the Elo and amount.
      const adjacent=text.match(/(?:^|\s)(\d{3,4})\s+(\d{1,3})\s+(?=\d+[.,]\d+\b)/);
      if(adjacent)parsed.delta=(parsed.won?1:-1)*Number(adjacent[2]);
    }
    if(parsed && !date){
      const tokens=parsed.day.match(/^(\d+)\s+([^. ,]+)\.?[ ,]*(\d{4})?$/u);
      if(tokens){
        const months=['янв','фев','мар','апр','май','июн','июл','авг','сен','окт','ноя','дек'];
        const en=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
        const name=tokens[2].toLowerCase().slice(0,3).replace('мая','май');
        const month=Math.max(months.indexOf(name),en.indexOf(name));
        if(month>=0)parsed.day=new Intl.DateTimeFormat(locale,{day:'numeric',month:'short',...(tokens[3]?{year:'numeric'}:{})}).format(new Date(Number(tokens[3]||2000),month,Number(tokens[1]),12));
      }
    }
    return parsed;
  }
  function stats(items){
    return items.reduce((s,m)=>{
      s.count++;if(m.won===true)s.wins++;if(m.won===false)s.losses++;
      if(m.delta!==null){s.known++;s.elo+=m.delta;}return s;
    },{count:0,wins:0,losses:0,elo:0,known:0});
  }
  const signed=n=>(n>0?'+':'')+n;
  return {parse,read,stats,signed};
})();
