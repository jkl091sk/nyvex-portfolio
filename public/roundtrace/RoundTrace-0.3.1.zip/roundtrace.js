(async () => {
  if (document.querySelector('roundtrace-panel')) return;
  const defaults = {days:true, match:false, party:false, focus:false, size:"large", language:navigator.language.toLowerCase().startsWith("en")?"en":"ru"};
  const store = globalThis.chrome?.storage?.local;
  const state = Object.assign({}, defaults, store ? await store.get(defaults) : JSON.parse(localStorage.getItem('roundtrace') || '{}'));
  const host = document.createElement('roundtrace-panel');
  document.body.append(host);
  const root = host.attachShadow({mode:'open'});
  root.innerHTML = `<style>
  :host{all:initial;position:fixed;inset:auto 12px 12px auto;z-index:2147483646;font:15px/1.45 Bahnschrift,"Segoe UI",system-ui,sans-serif;color:#f5f3ef;color-scheme:dark}
  *{box-sizing:border-box}button{font:inherit;color:inherit;cursor:pointer;background:none;border:0}button:focus-visible{outline:2px solid #f3c590;outline-offset:2px}
  #logo{width:44px;height:44px;display:grid;place-items:center;margin-left:auto}svg{width:29px;height:29px;filter:drop-shadow(0 1px 3px #000)}#logo:hover svg{transform:translateY(-1px)}
  section{position:absolute;right:0;bottom:52px;width:min(318px,calc(100vw - 24px));background:#181818;border:1px solid #383735;border-radius:11px;box-shadow:0 10px 34px #0009;overflow:hidden}
  header,footer{padding:13px 15px;display:flex;align-items:center;gap:9px}header{border-bottom:1px solid #323232}strong{font-size:17px;letter-spacing:-.5px}small{color:#a7a39f;font-size:10px}#close{margin-left:auto;font-size:20px;line-height:1}main{padding:8px 15px}.line{display:flex;align-items:center;justify-content:space-between;min-height:36px;gap:14px;width:100%;padding:0;text-align:left;font-size:13px}.switch{width:30px;height:17px;border-radius:12px;background:#565553;padding:2px}.switch:before{content:'';display:block;width:13px;height:13px;background:#ddd;border-radius:50%}[aria-checked=true] .switch{background:#f3c590}[aria-checked=true] .switch:before{transform:translateX(13px);background:#282018}
  footer{border-top:1px solid #323232}footer button{font-size:12px;color:#d5d1ca;padding:0}p{font-size:12px;color:#bcb8b1} [hidden]{display:none!important}
  section{width:min(460px,calc(100vw - 24px));max-height:calc(100dvh - 83px);overflow:auto}header{padding:16px 20px}header svg{width:34px;height:34px}header strong{font-size:23px}header small{font-size:12px}header button{min-width:32px;min-height:32px}
  nav{display:flex;gap:4px;padding:6px 12px;border-bottom:1px solid #383532}nav button{flex:1;padding:9px 4px;color:#c1bbb4;font-weight:600;font-size:16px}nav button[aria-pressed=true]{color:#f3c590;background:#292521;border-radius:5px}
  main{padding:12px 20px 18px}.line{font-size:20px;min-height:52px}.line+.line{border-top:1px solid #302e2b}.switch{width:42px;height:24px;padding:3px}.switch:before{width:18px;height:18px}[aria-checked=true] .switch:before{transform:translateX(18px)}
  :host([data-size=xl]) section{width:min(540px,calc(100vw - 24px))}:host([data-size=xl]) .line{font-size:23px;min-height:60px}:host([data-size=xl]) main{font-size:19px}:host([data-size=xl]) nav button{font-size:19px}
  label{display:block;margin:10px 0;font-size:1em;color:#e4ded8}select{display:block;margin-top:5px;width:100%;font:inherit;background:#252423;color:#f4eee6;padding:8px;border:1px solid #45403b;border-radius:5px}
  main{font-size:16px}h3{font-size:1.07em;margin:12px 0 8px}p{font-size:.93em;color:#c7c0b9;margin:8px 0}.summary{padding:10px 0;color:#f3c590;font-weight:600}.maprow{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #363331}.action{font-size:1em;padding:7px 10px;border:1px solid #51473c;border-radius:5px;margin:4px 5px 0 0}
  button:focus-visible,select:focus-visible{outline:2px solid #f3c590;outline-offset:-2px}section{scrollbar-width:thin;scrollbar-color:#685b4d #181818}header svg{flex:none}.credit{border-top:1px solid #383431;padding-top:12px;color:#aca69f}
  </style><section hidden aria-label="RoundTrace"><header><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><path fill="#F3C590" fill-rule="evenodd" d="M33 18H103C118 18 124 31 120 46L117 58C114 70 103 79 91 79H89L111 109H80L58 79H43L34 109H6L18 65H37a4.5 4.5 0 0 0 0-9H20Zm25 17c-4 0-7 3-8 7l-3 13c-1 4 1 7 6 7h33c5 0 9-3 10-8l2-9c1-6-2-10-8-10Z"/></svg><strong>RoundTrace</strong><small>by NYVEX</small><button id="close" aria-label="Закрыть">×</button></header><nav aria-label="Разделы"></nav><main></main></section><button id="logo" aria-label="Открыть RoundTrace" aria-expanded="false"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><path fill="#F3C590" fill-rule="evenodd" d="M33 18H103C118 18 124 31 120 46L117 58C114 70 103 79 91 79H89L111 109H80L58 79H43L34 109H6L18 65H37a4.5 4.5 0 0 0 0-9H20Zm25 17c-4 0-7 3-8 7l-3 13c-1 4 1 7 6 7h33c5 0 9-3 10-8l2-9c1-6-2-10-8-10Z"/></svg></button>`;
  const names={days:'История по дням',match:'Автопринятие матча',party:'Приглашения в пати',focus:'Режим фокуса'};
  const english = {
  "Меню": "Menu",
  "История": "History",
  "Вид": "Appearance",
  "История по дням": "Group matches by day",
  "Автопринятие матча": "Auto-accept matches",
  "Приглашения в пати": "Auto-accept party invites",
  "Режим фокуса": "Focus mode",
  "Открой историю матчей CS2. Сводка появится, когда FACEIT загрузит строки.": "Open your CS2 match history. Your summary appears once FACEIT loads the matches.",
  "Карта": "Map",
  "Все карты": "All maps",
  "Результат": "Result",
  "Все результаты": "All results",
  "Победы": "Wins",
  "Поражения": "Losses",
  "Сбросить фильтры": "Reset filters",
  "Развернуть дни": "Expand days",
  "Свернуть дни": "Collapse days",
  "По картам": "By map",
  "Под эти фильтры нет загруженных матчей.": "No loaded matches match these filters.",
  "Размер меню": "Menu size",
  "Крупный": "Large",
  "Очень крупный": "Extra large",
  "Размер применяется только к панели RoundTrace.": "This size applies only to the RoundTrace panel.",
  "Язык": "Language",
  "Закрыть": "Close",
  "Разделы": "Sections",
  "Открыть RoundTrace": "Open RoundTrace"
};
  const tr = value => state.language==="en" ? english[value] ?? value : value;
  const panel=root.querySelector('section'), logo=root.querySelector('#logo'), main=root.querySelector('main');
  let tab='Меню',mapFilter='',outcome='',matches=[],lastPath='',signature='';
  const nav=root.querySelector('nav');
  const collapsed=new Set(), clicked=new WeakSet();
  const plural=new Intl.PluralRules('ru');
  const matchCount=n=>state.language==='en' ? n+(n===1?' match':' matches') : n+' '+({one:'матч',few:'матча',many:'матчей'}[plural.select(n)]||'матчей');
  function node(tag,text,parent=main){const el=document.createElement(tag);el.textContent=tr(text);parent.append(el);return el;}
  function action(label,fn){const b=node('button',label);b.className='action';b.onclick=fn;}
  function select(label,choices,value,change){
    const wrap=node('label',label),input=node('select','',wrap);
    for(const [key,title] of choices)input.add(new Option(tr(title),key));
    input.value=value;input.onchange=()=>change(input.value);
  }
  function save(key,value){state[key]=value;if(store)store.set({[key]:value});else localStorage.setItem('roundtrace',JSON.stringify(state));refresh();}
  function visible(m){return (!mapFilter||m.map===mapFilter)&&(!outcome||m.won===(outcome==='win'));}
  function paint(){
    host.dataset.size=state.size;
    main.replaceChildren();
    root.querySelector('section').setAttribute('aria-label','RoundTrace · '+tr(tab));
    host.lang=state.language;
    logo.setAttribute('aria-label',tr('Открыть RoundTrace'));
    root.querySelector('#close').setAttribute('aria-label',tr('Закрыть'));
    nav.setAttribute('aria-label',tr('Разделы'));
    for(const btn of nav.children){btn.textContent=tr(btn.dataset.tab);btn.setAttribute('aria-pressed',btn.dataset.tab===tab);}
    if(tab==='Меню'){
      for(const [key,label] of Object.entries(names)){
        const btn=node('button',label);btn.className='line';btn.setAttribute('role','switch');btn.setAttribute('aria-checked',state[key]);
        node('i','',btn).className='switch';
        btn.onclick=()=>{save(key,!state[key]);btn.setAttribute('aria-checked',state[key]);};
      }
    }else if(tab==='История'){
      if(!matches.length){node('p','Открой историю матчей CS2. Сводка появится, когда FACEIT загрузит строки.');return;}
      const selected=matches.filter(visible),s=RoundHistory.stats(selected);
      node('p',state.language==='en' ? 'Loaded matches · '+selected.length+' of '+matches.length : 'По загруженным матчам · '+selected.length+' из '+matches.length);
      node('div',s.wins+'W-'+s.losses+'L'+(s.known===s.count&&s.count?' · '+RoundHistory.signed(s.elo)+' Elo':'')).className='summary';
      if(s.wins+s.losses)node('p',(state.language==='en'?'Win rate ':'Винрейт ')+Math.round(100*s.wins/(s.wins+s.losses))+'%');
      const mapNames=[...new Set(matches.map(m=>m.map).filter(Boolean))].sort();
      select('Карта',[['','Все карты'],...mapNames.map(k=>[k,k])],mapFilter,v=>{mapFilter=v;refresh();});
      select('Результат',[['','Все результаты'],['win','Победы'],['loss','Поражения']],outcome,v=>{outcome=v;refresh();});
      if(mapFilter||outcome)action('Сбросить фильтры',()=>{outcome=mapFilter='';refresh();});
      if(state.days && selected.length)action(selected.every(m=>collapsed.has(m.day))?'Развернуть дни':'Свернуть дни',()=>{
        const fold=!selected.every(m=>collapsed.has(m.day));
        for(const m of selected)if(fold)collapsed.add(m.day);else collapsed.delete(m.day);
        refresh();paint();
      });
      if(selected.length){node('h3','По картам');
        for(const map of mapNames){const sub=RoundHistory.stats(selected.filter(m=>m.map===map));if(!sub.count)continue;
          const line=node('div',map);line.className='maprow';node('span',matchCount(sub.count)+(sub.known===sub.count?' · '+RoundHistory.signed(sub.elo)+' Elo':''),line);}
      }else node('p','Под эти фильтры нет загруженных матчей.');
    }else{
      select('Язык',[['ru','Русский'],['en','English']],state.language,v=>{save('language',v);paint();});
      select('Размер меню',[['large','Крупный'],['xl','Очень крупный']],state.size,v=>{save('size',v);host.dataset.size=v;});
      node('p','Размер применяется только к панели RoundTrace.');
      node('p','RoundTrace 0.3.1 · NYVEX').className='credit';
    }
  }
  for(const name of ['Меню','История','Вид']){
    const btn=node('button',name,nav);btn.dataset.tab=name;btn.onclick=()=>{tab=name;paint();};
  }
  function open(show,focus=true){
    panel.hidden=!show;logo.setAttribute('aria-expanded',show);
    if(show){paint();root.querySelector('#close').focus();}else if(focus)logo.focus();
  }
  logo.onclick=()=>open(panel.hidden);root.querySelector('#close').onclick=()=>open(false);
  document.addEventListener('pointerdown',e=>{if(!panel.hidden&&!e.composedPath().includes(host))open(false,false);});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden)open(false);});
  function header(row,day){
    let marker=row.previousElementSibling;
    if(!marker?.hasAttribute('data-rt-day')){
      const table=row.tagName==='TR'||getComputedStyle(row).display==='table-row'||getComputedStyle(row.parentElement).display.startsWith('table');
      marker=document.createElement(table?'tr':'div');marker.setAttribute('data-rt-day','');
      const box=table?marker.insertCell():marker;if(table)box.colSpan=99;
      const btn=node('button','',box);btn.type='button';btn.className='rt-day-control';
      node('b','',btn);node('small','',btn);row.before(marker);
    }
    const btn=marker.querySelector('button');
    btn.onclick=()=>{if(collapsed.has(day))collapsed.delete(day);else collapsed.add(day);refresh();};
    btn.setAttribute('aria-expanded',!collapsed.has(day));return marker;
  }
  function group(){
    if(location.pathname!==lastPath){mapFilter=outcome='';collapsed.clear();lastPath=location.pathname;}
    const old=new Set(document.querySelectorAll('[data-rt-day]')),rows=new Map(),ids=new Set();
    if(/\/history\/?$/.test(location.pathname)){
      for(const item of document.querySelectorAll('a[href*="/room/"],tr,[role="row"]')){
        const row=item.closest('tr,[role="row"]')||item;
        if(rows.has(row)||row.hasAttribute('data-rt-day'))continue;
        const m=RoundHistory.read(row,state.language);if(!m)continue;
        const href=(row.matches('a')?row:row.querySelector('a[href*="/room/"]'))?.href;
        if(href && ids.has(href))continue;if(href)ids.add(href);
        rows.set(row,m);
      }
    }
    matches=[...rows.values()];
    let current=null;const groups=[];
    for(const [row,m] of rows){
      row.toggleAttribute('data-rt-hidden',!visible(m)||(state.days&&collapsed.has(m.day)));
      if(!state.days||!visible(m))continue;
      if(!current||current.day!==m.day||current.parent!==row.parentElement){
        current={day:m.day,parent:row.parentElement,items:[],marker:header(row,m.day)};
        groups.push(current);old.delete(current.marker);
      }
      current.items.push(m);
    }
    for(const {marker,items,day} of groups){
      const s=RoundHistory.stats(items);
      marker.querySelector('b').textContent=(collapsed.has(day)?'▸  ':'▾  ')+day+' · '+matchCount(s.count);
      const total=marker.querySelector('small');
      total.textContent=(s.wins+s.losses?s.wins+'W-'+s.losses+'L':'')+(s.known===s.count?' · '+RoundHistory.signed(s.elo)+' Elo':' · Elo —');
      total.style.color=s.known===s.count&&s.elo?(s.elo>0?'#9bd49f':'#ee9991'):'';
    }
    for(const marker of old)marker.remove();
    for(const row of document.querySelectorAll('[data-rt-hidden]'))if(!rows.has(row))row.removeAttribute('data-rt-hidden');
    const next=JSON.stringify([matches,mapFilter,outcome]);
    if(next!==signature){signature=next;if(tab==='История'&&!panel.hidden)paint();}
  }
  function refresh(){
    observer.disconnect();
    try {
    group();
    for(const chat of document.querySelectorAll('[data-testid="matchroom-chat"],[data-testid="match-room-chat"],[data-rt-chat]')){
      const hide=state.focus && location.pathname.includes('/room/');
      chat.toggleAttribute('data-rt-chat',hide);
    }
    if(state.match||state.party)for(const dialog of document.querySelectorAll('[role="dialog"],[role="alertdialog"]')){
      const message=dialog.innerText;
      if(!(state.match&&/match found|матч найден/i.test(message)||state.party&&/party invitation|приглашение в (?:пати|группу)/i.test(message)))continue;
      const accept=[...dialog.querySelectorAll('button:not(:disabled)')].find(b=>/^(accept(?: match| invitation)?|принять(?: матч| приглашение)?)$/i.test(b.innerText.trim()));
      if(accept && !clicked.has(accept)){clicked.add(accept);accept.click();}
    }
    } finally {
      observer.observe(document.body,{childList:true,subtree:true,characterData:true});
    }
  }
  let timer;
  const observer=new MutationObserver(()=>{if(!timer)timer=setTimeout(()=>{timer=null;refresh();},180);});
  if(store)chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local')return;
    let changed=false;
    for(const key in defaults){
      if(!changes[key])continue;
      const next=changes[key].newValue??defaults[key];
      if(next!==state[key]){state[key]=next;changed=true;}
    }
    if(changed){paint();refresh();}});
  paint();refresh();
})();
